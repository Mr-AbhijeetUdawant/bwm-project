import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { RentalDetailsComponent } from './rental-details/rental-details.component';
import { RentalListComponent } from './rental-list/rental-list.component';
import { RentalComponent } from './rental.component';
import { RentalService } from './rental.service';



const routes: Routes = [
    {path:"rental",component:RentalComponent,
    children:[
    {path:"",component:RentalListComponent,pathMatch:"full"},
    {path:":rentalId",component:RentalDetailsComponent}
    ]},


];

@NgModule({
  declarations:[
    RentalListComponent,
    RentalDetailsComponent
  ],
  imports: [
      RouterModule.forChild(routes),
      CommonModule,
      BrowserModule
        ],
  providers: [RentalService]
})
export class RentalModule{ }