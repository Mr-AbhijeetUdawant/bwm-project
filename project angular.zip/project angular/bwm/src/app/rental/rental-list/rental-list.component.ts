import { Component, OnInit } from '@angular/core'
import { IRental } from 'src/app/shared/rental.interface'
import { Rental } from '../../shared/rental.model'
import { RentalService } from '../rental.service'
import { AppStorage } from '../../shared/rental.interface'

@Component({
  selector: 'app-rental-list',
  templateUrl: './rental-list.component.html',
  styleUrls: ['./rental-list.component.scss']
})
export class RentalListComponent implements OnInit, IRental {
  rental!: Rental[]

  constructor (private rentalService: RentalService) {}
  someData!: 'Ajay'
  isLoaded!: true
  implementMe (): string {
    return ''
  }
  _id!: string
  title!: string
  city!: string
  street!: string
  category!: string
  image!: string
  numOfRooms!: number
  description!: string
  dailyPrice!: number
  shared!: boolean
  createdAt!: string

  ngOnInit (): void {
    this.rentalService.getRentals().subscribe((rentals: any) => {
      this.rental = rentals

      const appStorage = new AppStorage<number>()
      appStorage.addItem(10)
      appStorage.addItem(20)
      appStorage.addItem(50)
      let item=appStorage.getItem(1)
      let items=appStorage.displayItems()
      console.log(item,items);
    })
  }
}
