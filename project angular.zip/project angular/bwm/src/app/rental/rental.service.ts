import { Injectable } from "@angular/core"
import { Observable } from "rxjs"
import { Rental } from "../shared/rental.model"

// @Injectable()
export class RentalService{
    rentals:Rental[]=[
        {
          _id:"1013",
        title!:"Central Apartment",
        city:"san frasicko",
        street:"rayencha avenue",
        category:"AC",
        image:"",
        numOfRooms:5,
        description:"This is a good place for family and couples",
        dailyPrice:5000,
        shared:true,
        createdAt:"10 july 2000"
        },
        {
          _id:"2002",
        title!:"Central Apartment2",
        city:"california",
        street:"john street",
        category:"Non-Ac",
        image:"",
        numOfRooms:10,
        description:"having swimming pool and a good beautiful place near it",
        dailyPrice:5000,
        shared:true,
        createdAt:"15 january 2013"
        }
      ]

      getRentals(){
          return new Observable((observer) =>{
              setTimeout(() => {
                observer.next(this.rentals)
              }, 1000)
          })
      }
}